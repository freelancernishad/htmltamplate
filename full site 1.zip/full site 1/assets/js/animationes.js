

/* var waypoint = new Waypoint({
  element: document.getElementById('px-offset-waypoint'),
  handler: function(direction) {
    notify('I am 20px from the top of the window')
  },
  offset: 20 
});
 */

$(document).ready(function(){
	
		$("#addclass").waypoint(function(direction){
		$("#addclass").addClass("animated bounceIns")
		
		
	},
	{
		offset:"100%"
		
	}
	)	
		$("#addclasses").waypoint(function(direction){
		$("#addclasses").addClass("animated bounceIns")
		
		
	},
	{
		offset:"100%"
		
	}
	)	
	$(".downTotop").waypoint(function(direction){
		$(".downTotop").addClass("animated zoomInDown")
		
		
	},
	{
		offset:"100%"
		
	}
	)	
	
	$(".bounce").waypoint(function(direction){
		$(".bounce").addClass("animated bounceIns")
		
		
	},
	{
		offset:"100%"
		
	}
	)	

	
	$(".bounce2").waypoint(function(direction){
		$(".bounce2").addClass("animated bounceIns2")
		
		
	},
	{
		offset:"100%"
		
	}
	)	

	
	$(".bounce3").waypoint(function(direction){
		$(".bounce3").addClass("animated bounceIns3")
		
		
	},
	{
		offset:"100%"
		
	}
	)	

	
	$(".bounce4").waypoint(function(direction){
		$(".bounce4").addClass("animated bounceIns4")
		
		
	},
	{
		offset:"100%"
		
	}
	)	
	
	$(".bounce_icon").waypoint(function(direction){
		$(".bounce_icon").addClass("animated bounceIns")
		
		
	},
	{
		offset:"100%"
		
	}
	)	
	
	$(".downTotop2").waypoint(function(direction){
		$(".downTotop2").addClass("animated zoomInDown")
		
		
	},
	{
		offset:"100%"
		
	}
	)	
	
	$(".work_menu_list").waypoint(function(direction){
		$(".work_menu_list").addClass("animated bounceIns")
		
		
	},
	{
		offset:"100%"
		
	}
	)
	$(".work_img_bounce").waypoint(function(direction){
		$(".work_img_bounce").addClass("animated bounceIns")
		
		
	},
	{
		offset:"100%"
		
	}
	)

	$(".work_img_bounce2").waypoint(function(direction){
		$(".work_img_bounce2").addClass("animated bounceIns3")
		
		
	},
	{
		offset:"100%"
		
	}
	)	

	$(".carousel-inner").waypoint(function(direction){
		$(".carousel-inner").addClass("animated bounceIns")
		
		
	},
	{
		offset:"100%"
		
	}
	)	
	

	$(".client_bounce").waypoint(function(direction){
		$(".client_bounce").addClass("animated bounceIns")
		
		
	},
	{
		offset:"100%"
		
	}
	)	
	

	$(".full_details").waypoint(function(direction){
		$(".full_details").addClass("animated bounceIns4")
		
		
	},
	{
		offset:"100%"
		
	}
	)	

	$(".team_social").waypoint(function(direction){
		$(".team_social").addClass("animated slideInRights")
		
		
	},
	{
		offset:"100%"
		
	}
	)	

	$(".section7_bounce").waypoint(function(direction){
		$(".section7_bounce").addClass("animated bounceIns4")
		
		
	},
	{
		offset:"100%"
		
	}
	)
	$(".section6_animate").waypoint(function(direction){
		$(".section6_animate").addClass("animated zoomInDown")
		
		
	},
	{
		offset:"100%"
		
	}
	)

	$(".skill_details").waypoint(function(direction){
		$(".skill_details").addClass("animated bounceIns")
		
		
	},
	{
		offset:"100%"
		
	}
	)
	$(".skill_toggols").waypoint(function(direction){
		$(".skill_toggols").addClass("animated bounceIns4")
		
		
	},
	{
		offset:"100%"
		
	}
	)
	
	
	$(".slide_left").waypoint(function(direction){
		$(".slide_left").addClass("animated slideInLeft")
		
		
	},
	{
		offset:"100%"
		
	}
	)	
	
	
	$(".slide_right").waypoint(function(direction){
		$(".slide_right").addClass("animated slideInRight")
		
		
	},
	{
		offset:"100%"
		
	}
	)	
	
	
	$(".contact_us").waypoint(function(direction){
		$(".contact_us").addClass("animated zoomInDown")
		
		
	},
	{
		offset:"100%"
		
	}
	)	


	
	$(".address").waypoint(function(direction){
		$(".address").addClass("animated bounceIns")
		
		
	},
	{
		offset:"100%"
		
	}
	)	


	
	$(".social_icon").waypoint(function(direction){
		$(".social_icon").addClass("animated bounceIns")
		
		
	},
	{
		offset:"100%"
		
	}
	)	

});
