$(document).ready(function(){
		$('.skill_toggol').click(function(){
			$(this).toggleClass('color_change')
			$('.toggole-plus').toggleClass('hide')
			$('.toggole-minus').toggleClass('hide')
			
			
			
		})
		
				$('.skill_toggol1').click(function(){
					$(this).toggleClass('color_change')
			$('.toggole-plus1').toggleClass('hide1')
			$('.toggole-minus1').toggleClass('hide1')
			
			
			
		})
		
				$('.skill_toggol2').click(function(){
					$(this).toggleClass('color_change')
			$('.toggole-plus2').toggleClass('hide2')
			$('.toggole-minus2').toggleClass('hide2')
			
			
			
		})
		
				$('.skill_toggol3').click(function(){
					$(this).toggleClass('color_change')
			$('.toggole-plus3').toggleClass('hide3')
			$('.toggole-minus3').toggleClass('hide3')
			
			
			
		})
		
		
		
		
	})
	
	